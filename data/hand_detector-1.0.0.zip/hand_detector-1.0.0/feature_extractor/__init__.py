from feature_extractor.model import MogaNet
from feature_extractor.test import MNIST_dataset_configure, MNISTransform
