from feature_extractor.model import MogaNet
