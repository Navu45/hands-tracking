from model import MogaNet
